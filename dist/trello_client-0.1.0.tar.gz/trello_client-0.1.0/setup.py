# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['trello_client']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.4.0,<0.5.0', 'requests>=2.25.1,<3.0.0']

entry_points = \
{'console_scripts': ['trello_client = trello_client.main:cli']}

setup_kwargs = {
    'name': 'trello-client',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'azat715',
    'author_email': 'azat715@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
